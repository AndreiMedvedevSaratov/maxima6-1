// Адрес сервера
export const SERVER_URL = "http://localhost:5000/comments";

// HTTP-методы
export const POST = "POST";
export const DELETE = "DELETE";
export const PUT = "PUT";

// Операции
export const UPDATE = "UPDATE";
export const REMOVE = "REMOVE";
